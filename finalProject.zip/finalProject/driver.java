package finalProject;

import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class driver {

	public static void main(String[] args) throws Exception {
		
		JFrame application =new frame3();
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				application.setVisible(true);
				application.setTitle("Tender");
	}

}
